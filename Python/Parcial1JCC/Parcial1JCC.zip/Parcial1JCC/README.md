## Proyecto Parcial 1 - Inforgrafia UPB
### Juan Claudio Carrasco Tapia 60715
### Juego de salto de plataformas en PyGame
El juego consiste en utilizar las teclas A y D para mantener al personaje del juego sobre las plataformas que iran descendiendo en cuanto el personaje las salte
Al mismo tiempo sera necesario evadir a los enemigos que se mueven de un lado de la pantalla al otro, el objetivo del juego será jugar repetidas veces con tal de superar el propio puntaje mas alto del jugador. 
Para ejecutar el juego es necesario tener VS Code instalado, descomprimir el archivo .zip al ordenador y abrir el archivo game.py, luego ejecutar el codigo en VS Code y ya se tendrá al juego corriendo.